export const CST = {
    SCENES: {
        LOAD: "LOAD",
        MENU: "MENU",
        PLAYP1: "PLAYP1",
        PLAYP2: "PLAYP2"
    }
}